/* 
CIT 281 Project 1
Name: Catherine Nolan
*/ 

// Returns a random number between min (5) (inclusive) and max (26) (exclusive) 
function getRandomInteger (min, max) { 
    return Math.floor(Math.random() * (max - min) + min);  
}


//random array lentgth of lower casae letters 
let letter = "abcdefghijklmnopqrstuvwxyz"; 
let length = getRandomInteger(5, 26) //min=5 (inclusive), max=26 (exclusive)
let str = ''; 
for (let i = 0; i < length; i++) {
    str = str + letter.charAt(getRandomInteger(0, letter.length)); 
}

console.log(str); 