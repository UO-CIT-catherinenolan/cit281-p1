/*
CIT 281 Project 1
Name: Catherine Nolan 
*/ 
const day =["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
let now = new Date (); 
console.log (day[now.getDay()]); 